package com.your_package_name

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment() {

    private lateinit var homeButton: Button
    private lateinit var harvestButton: Button
    private lateinit var pestButton: Button

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
            // Inflate the layout for this fragment
            val view = inflater.inflate(R.layout.fragment_home, container, false)

            // Initialize buttons
            homeButton = view.findViewById(R.id.home_button)
            harvestButton = view.findViewById(R.id.harvest_button)
            pestButton = view.findViewById(R.id.pest_button)

            // Set button click listeners
            homeButton.setOnClickListener { fetchApiData() }

    return view
    }

    private fun fetchApiData() {
        // Retrofit setup
        val retrofit = Retrofit.Builder()
                .baseUrl("https://api.example.com/")  // Replace with your API URL
                .addConverterFactory(GsonConverterFactory.create())
                .build()

        val apiService = retrofit.create(ApiService::class.java)

        // Make the API call
        apiService.getData().enqueue(object : Callback<YourDataModel> {
            override fun onResponse(call: Call<YourDataModel>, response: Response<YourDataModel>) {
                if (response.isSuccessful) {
                    val data = response.body()
                    // Handle API response, e.g., update the UI
                }
            }

            override fun onFailure(call: Call<YourDataModel>, t: Throwable) {
                // Handle failure
            }
        })
    }
}
