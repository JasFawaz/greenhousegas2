package com.example.agritech;

public class HomeFragment {
}
